from flask import Blueprint, request, jsonify
from app.models import db, Task
from datetime import datetime

tasks_bp = Blueprint('tasks', __name__)

# ------------------ CRUD ------------------

@tasks_bp.route('/tasks', methods=['GET'])
def get_tasks():
    tasks = Task.query.all()
    return jsonify([t.to_dict() for t in tasks])


@tasks_bp.route('/tasks', methods=['POST'])
def create_task():
    data = request.json

    task = Task(
        title=data['title'],
        description=data.get('description'),
        priority=data.get('priority', 'Medium'),
        status='Pending',
        due_date=datetime.fromisoformat(data['due_date'])
    )

    db.session.add(task)
    db.session.commit()

    return jsonify(task.to_dict())


@tasks_bp.route('/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    task = Task.query.get_or_404(task_id)
    
    data = request.json

    if 'title' in data:
        task.title = data['title']
    if 'description' in data:
        task.description = data['description']
    if 'priority' in data:
        task.priority = data['priority']
    if 'status' in data:
        task.status = data['status']
    if 'due_date' in data:
        task.due_date = datetime.fromisoformat(data['due_date'])

    db.session.commit()
    return jsonify(task.to_dict())


@tasks_bp.route('/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)

    db.session.delete(task)
    db.session.commit()

    return jsonify({"message": "Task deleted"})


# ------------------ 🤖 SIMPLE AI (NO API) ------------------

@tasks_bp.route('/tasks/<int:task_id>/ai-suggest', methods=['POST'])
def ai_suggest(task_id):
    task = Task.query.get_or_404(task_id)

    title = task.title.lower()

    # 🔥 Smart keyword-based logic
    if any(word in title for word in ["urgent", "asap", "immediately", "deadline"]):
        return jsonify({
            "priority": "High",
            "suggestion": "This task is urgent. Complete it as soon as possible."
        })

    elif any(word in title for word in ["later", "someday", "optional"]):
        return jsonify({
            "priority": "Low",
            "suggestion": "This task can be scheduled for later."
        })

    elif any(word in title for word in ["meeting", "project", "exam", "submit"]):
        return jsonify({
            "priority": "High",
            "suggestion": "Important task. Plan properly and complete on time."
        })

    else:
        return jsonify({
            "priority": "Medium",
            "suggestion": "Manage your time and complete this task efficiently."
        })