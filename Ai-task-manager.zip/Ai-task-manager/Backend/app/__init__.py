from flask import Flask
from flask_cors import CORS
from app.config import Config
from app.models import db
from app.routes.tasks import tasks_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    CORS(app)
    db.init_app(app)

    app.register_blueprint(tasks_bp, url_prefix='/api')

    @app.route("/")
    def home():
        return "Backend is working 🚀"

    with app.app_context():
        db.create_all()

    return app