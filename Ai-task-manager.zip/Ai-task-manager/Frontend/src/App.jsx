import { useEffect, useState } from "react";

function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [aiData, setAiData] = useState({});
  const [loadingId, setLoadingId] = useState(null);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = () => {
    fetch("http://127.0.0.1:5000/api/tasks")
      .then(res => res.json())
      .then(data => setTasks(data));
  };

  // ✅ ADD TASK
  const addTask = () => {
    if (!title.trim()) return;

    fetch("http://127.0.0.1:5000/api/tasks", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        title,
        description: "",
        priority: "Medium",
        due_date: new Date().toISOString()
      })
    })
      .then(res => res.json())
      .then(data => {
        setTasks([data, ...tasks]);
        setTitle("");
      });
  };

  // ✅ DELETE
  const deleteTask = (id) => {
    fetch(`http://127.0.0.1:5000/api/tasks/${id}`, {
      method: "DELETE"
    }).then(() => {
      setTasks(tasks.filter(t => t.id !== id));
    });
  };

  // ✅ TOGGLE STATUS
  const toggleStatus = (task) => {
    const newStatus = task.status === "Pending" ? "Completed" : "Pending";

    fetch(`http://127.0.0.1:5000/api/tasks/${task.id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ status: newStatus })
    })
      .then(res => res.json())
      .then(updated => {
        setTasks(tasks.map(t => t.id === updated.id ? updated : t));
      });
  };

  // 🤖 AI SUGGEST
  const getAISuggestion = (id) => {
    setLoadingId(id);

    fetch(`http://127.0.0.1:5000/api/tasks/${id}/ai-suggest`, {
      method: "POST"
    })
      .then(res => res.json())
      .then(data => {
        setAiData(prev => ({ ...prev, [id]: data }));

        // 🔥 AUTO PRIORITY UPDATE
        fetch(`http://127.0.0.1:5000/api/tasks/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ priority: data.priority })
        });
      })
      .finally(() => setLoadingId(null));
  };

  return (
    <div style={{ padding: "20px", maxWidth: "650px", margin: "auto" }}>
      <h1 style={{ textAlign: "center" }}>🚀 AI Task Manager</h1>

      {/* ADD TASK */}
      <div style={{ marginBottom: "20px", display: "flex", gap: "10px" }}>
        <input
          placeholder="Enter task..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") addTask();
          }}
          style={{ padding: "10px", flex: 1 }}
        />
        <button onClick={addTask}>Add</button>
      </div>

      {/* TASK LIST */}
      {tasks.length === 0 ? (
        <p style={{ textAlign: "center", color: "gray" }}>
          No tasks yet. Add your first task 🚀
        </p>
      ) : (
        tasks.map(task => (
          <div
            key={task.id}
            style={{
              border: "1px solid #ddd",
              padding: "15px",
              margin: "12px 0",
              borderRadius: "10px",
              background:
                task.status === "Completed" ? "#e6f4ea" :
                task.is_overdue ? "#ffe5e5" : "#fff"
            }}
          >
            <h3 style={{
              textDecoration: task.status === "Completed" ? "line-through" : "none"
            }}>
              {task.title}
            </h3>

            <p><b>Status:</b> {task.status}</p>

            <p>
              <b>Priority:</b>{" "}
              <span style={{
                color:
                  task.priority === "High" ? "red" :
                  task.priority === "Medium" ? "orange" : "green"
              }}>
                {task.priority}
              </span>
            </p>

            {/* AI RESULT */}
            {aiData[task.id] && (
              <div style={{
                background: "#eef4ff",
                padding: "10px",
                borderRadius: "8px",
                marginTop: "10px"
              }}>
                <p><b>🤖 AI:</b> {aiData[task.id].suggestion}</p>
                <p>Priority: {aiData[task.id].priority}</p>
              </div>
            )}

            {/* BUTTONS */}
            <div style={{ marginTop: "10px", display: "flex", gap: "10px" }}>
              <button onClick={() => toggleStatus(task)}>
                {task.status === "Pending" ? "Complete" : "Undo"}
              </button>

              <button
                onClick={() => deleteTask(task.id)}
                style={{ color: "red" }}
              >
                Delete
              </button>

              <button
                onClick={() => getAISuggestion(task.id)}
                disabled={loadingId === task.id}
              >
                {loadingId === task.id ? "Loading..." : "AI Suggest"}
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default App;